#!/bin/bash
#
# Detta skript hämtar alla egenmodifierade html- och php-filer, flaggbild, caddyfil samt exkluderingslistan för arter
# och lägger dessa som backup.
# Filerna index2.php och views2.php sparas inte längre eftersom de för närvarande inte fungerar i Nachtzuster-versionen.
# Uppdaterat 2025-08-07  /L-Å
#
rm /home/userid-att-andra/BirdNET-Pi/Translate/egnafiler/*.*
cp /home/userid-att-andra/BirdNET-Pi/scripts/links.php /home/userid-att-andra/BirdNET-Pi/Translate/egnafiler
cp /home/userid-att-andra/BirdNET-Pi/exclude_species_list.txt /home/userid-att-andra/BirdNET-Pi/Translate/egnafiler
cp /home/userid-att-andra/BirdNET-Pi/whitelist_species_list.txt /home/userid-att-andra/BirdNET-Pi/Translate/egnafiler
cp /home/userid-att-andra/BirdNET-Pi/homepage/images/flagga.jpg /home/userid-att-andra/BirdNET-Pi/Translate/egnafiler
cp /home/userid-att-andra/BirdNET-Pi/homepage/images/feather.png /home/userid-att-andra/BirdNET-Pi/Translate/egnafiler
cp /home/userid-att-andra/BirdNET-Pi/homepage/index.php /home/userid-att-andra/BirdNET-Pi/Translate/egnafiler
# cp /home/userid-att-andra/BirdNET-Pi/homepage/index2.php /home/userid-att-andra/BirdNET-Pi/Translate/egnafiler
cp /home/userid-att-andra/BirdNET-Pi/homepage/views.php /home/userid-att-andra/BirdNET-Pi/Translate/egnafiler
# cp /home/userid-att-andra/BirdNET-Pi/homepage/views2.php /home/userid-att-andra/BirdNET-Pi/Translate/egnafiler
cp /home/userid-att-andra/BirdNET-Pi/homepage/style.css /home/userid-att-andra/BirdNET-Pi/Translate/egnafiler
cp /home/userid-att-andra/BirdNET-Pi/model/labels.txt /home/userid-att-andra/BirdNET-Pi/Translate/egnafiler
cp /home/userid-att-andra/BirdNET-Pi/scripts/birds.db /home/userid-att-andra/BirdNET-Pi/Translate/egnafiler
cp /home/userid-att-andra/BirdNET-Pi/scripts/daily_plot.py /home/userid-att-andra/BirdNET-Pi/Translate/egnafiler
cp /home/userid-att-andra/BirdNET-Pi/scripts/qa.php /home/userid-att-andra/BirdNET-Pi/Translate/egnafiler
cp /home/userid-att-andra/BirdNET-Pi/birdnet.conf /home/userid-att-andra/BirdNET-Pi/Translate/egnafiler
cp /home/userid-att-andra/BirdNET-Pi/model/labels.txt /home/userid-att-andra/BirdNET-Pi/Translate/egnafiler
cp /etc/caddy/Caddyfile /home/userid-att-andra/BirdNET-Pi/Translate/egnafiler



