#!/bin/bash

# Detta skript körs direkt efter nyinstallation eller uppdatering för att spara undan originalfiler.
# Uppdaterat 2022-04-30  /L-Å
#
cp /home/userid-att-andra/BirdNET-Pi/homepage/*.* /home/userid-att-andra/BirdNET-Pi/Translate/homepageorg
cp /home/userid-att-andra/BirdNET-Pi/scripts/*.php /home/userid-att-andra/BirdNET-Pi/Translate/scriptsorg
cp /home/userid-att-andra/BirdNET-Pi/scripts/*.py /home/userid-att-andra/BirdNET-Pi/Translate/scriptsorg
cp /home/userid-att-andra/BirdNET-Pi/scripts/*.sh /home/userid-att-andra/BirdNET-Pi/Translate/scriptsorg


 