#!/bin/bash

# Detta skript körs innan nyinstallation eller uppdatering för att läsa tillbaks originalfiler.
# Uppdaterat 2022-04-27  /L-Å
#
cp /home/userid-att-andra/BirdNET-Pi/Translate/homepageorg/*.* /home/userid-att-andra/BirdNET-Pi/homepage
cp /home/userid-att-andra/BirdNET-Pi/Translate/scriptsorg/*.* /home/userid-att-andra/BirdNET-Pi/scripts

 